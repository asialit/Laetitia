 <div class="container p-0" id="oferta-page" style="margin-bottom:150px">
                  <div class="row p-0 text-center">
                              <div id="heading">
                                    <h2><i class="fa fa-shopping-basket" aria-hidden="true"></i>Mój koszyk </h2>
                                    <hr>
                                    <p>Ilość produktów: </p>
                              </div>
                        </div>
	</div>


<div class="container">
<div class="row text-center">
	<div class="col-lg-7 orderform">
		<table class="table card">


			<tr>

				<td>
					<div class="col-lg-3">
						<img src="<?php echo ROOT_PATH; ?>assets/img/flower5.png" height="200px">

					</div>
				</td>
				<td>
					<div class="col-lg-9"><br>
						<p class=h4>Bukiet Matylda</p>
						<p class="text-muted">róża, goździk, gerber, tanacetum, dekoracyjne zielone liście </p>
						<p class="h6">Mały <a href="#">(Zmień)</a></p>
						<p class="h6">Z etykietą <i class="fa fa-tag" aria-hidden="true"></i><a href="#">(Zmień)</a></p>
						<p class="h6">Ilość: <span>1</span> <a href="#">(Zmień)</a></p>
						<p class="h3">Cena: 20 zł</p>


					</div>
				</td>




			</tr>

			<tr>

				<td>
					<div class="col-lg-3">
						<img src="<?php echo ROOT_PATH; ?>assets/img/flower5.png" height="200px">

					</div>
				</td>
				<td>
					<div class="col-lg-9"><br>
						<p class=h4>Bukiet Matylda</p>
						<p class="text-muted">róża, goździk, gerber, tanacetum, dekoracyjne zielone liście </p>
						<p class="h6">Mały <a href="#">(Zmień)</a></p>
						<p class="h6">Z etykietą <i class="fa fa-tag" aria-hidden="true"></i><a href="#">(Zmień)</a></p>
						<p class="h6">Ilość: <span>1</span> <a href="#">(Zmień)</a></p>
						<p class="h3">Cena: 20 zł</p>


					</div>
				</td>
			</tr>

			<tfoot class="tablefoot">
				<tr>
					<td> <a href="#">&larr; Kontynuuj zakupy</a>
						<p class="h3">Łącznie do zapłaty: kwota </p>
					</td>
				</tr>

			</tfoot>
		</table>
	</div>

	<div class="col-lg-5 orderform">
		<form>
			<div class="form-group">
				<label for="formGroupExampleInput">Imię i nazwisko*:</label>
				<input type="text" class="form-control" placeholder="Podaj imię i nazwisko" required>
			</div>
			<div class="form-group">
				<label for="formGroupExampleInput">Telefon*:</label>
				<input type="tel" class="form-control bfh-phone" data-format="+48 ddd-ddd-ddd" id="replyNumber" min="0" placeholder="(+48)" required>
			</div>
			<div class="form-group">
				<label for="formGroupExampleInput">E-mail*:</label>
				<input type="email" class="form-control" placeholder="Podaj e-mail" required>
			</div>
			<div class="form-group">
				<label for="formGroupExampleInput">Data odbioru bukietu*:</label>
				<input type="datetime-local" data-format="dd/MM/yyyy" class="form-control" placeholder="Wybierz termin" required>
			</div>

			<div class="form-group">
				<label for="formGroupExampleInput">Dodatkowe uwagi:</label>
				<textarea class="form-control noresize" rows="4" id="comment"></textarea>
			</div>

			<div class="form-group">
				<button class="btn btn-primary btn-lg">Zamawiam! <i class="fa fa-check" aria-hidden="true"></i></button>

			</div>
		</form>

	</div>
</div>
</div>