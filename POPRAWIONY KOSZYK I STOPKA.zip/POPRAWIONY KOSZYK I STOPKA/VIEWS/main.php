<!DOCTYPE html>
<html lang="pl_PL">

<head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <title>Document</title>

      <!-- FONTS -->
      <link href="https://fonts.googleapis.com/css?family=Quicksand:400,500&amp;subset=latin-ext" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Clicker+Script&amp;subset=latin-ext" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Bilbo" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Comfortaa:300,400&amp;subset=latin-ext" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Marck+Script&amp;subset=latin-ext" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Jim+Nightshade&amp;subset=latin-ext" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300,300i&amp;subset=latin-ext" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Caveat&amp;subset=latin-ext" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Lovers+Quarrel&amp;subset=latin-ext" rel="stylesheet">
	  <link href="https://fonts.googleapis.com/css?family=Patrick+Hand&amp;subset=latin-ext" rel="stylesheet">
      <!-- CSS // JQUERY // BOOTSTRAP // F-Awesome -->
      <link rel="stylesheet" href="<?php echo ROOT_PATH; ?>assets/css/font-awesome.css">
      <link rel="stylesheet" href="<?php echo ROOT_PATH; ?>assets/css/bootstrap.min.css">
      <link rel="stylesheet" href="<?php echo ROOT_PATH; ?>assets/css/kwiaciarnia.css" type="text/css" />
      <link rel="stylesheet" type="text/css" href="<?php echo ROOT_PATH; ?>assets/css/twentytwenty.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	  <link href="<?php echo ROOT_PATH; ?>assets/css/hover-min.css" rel="stylesheet" media="all">
     

</head>

<body>
      <!-- MAIN BAR NAVIGATION --> 
      
       
     <nav class="navbar navbar-dark bg-dark text-right row" id="nav-main">
     
     <div class="col-sm-2 text-center">
  <a class="navbar-brand" href="../sites/kwiaciarnia.html"><span><img src="<?php echo ROOT_PATH; ?>assets/img/logolwobg.png" height="40px"></span> Kwiaciarnia Laetitia </a>
</div>	
    <div class="col-sm-10 text-right">
    
  <button class="navbar-toggler" style="border-style:none;" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span id="navnav">Menu</span>
   <span class="navbar-toggler-icon" style="padding-left: 50px;"></span> 
  </button>
  </div>
 
  
  
  
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
  <div class="row">
  <div class="col-sm-6">
    <ul class="nav nav-tabs nav-flex">
     
      <li class="nav-item active">
        <a class="nav-link" href="#">Strona główna <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown active">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Oferta
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
           <a class="dropdown-item" href="<?php echo ROOT_URL; ?>oferta">Zobacz wszystkie kategorie</a>
          <a class="dropdown-item" href="<?php echo ROOT_URL; ?>dzienbabciidziadka">Dzień Babci i Dzień Dziadka</a>
          <a class="dropdown-item" href="<?php echo ROOT_URL; ?>wesele">Wesele</a>
          <a class="dropdown-item" href="<?php echo ROOT_URL; ?>dzienmatki">Dzień Matki</a>
          <a class="dropdown-item" href="<?php echo ROOT_URL; ?>walentynki">Walentynki</a>
          <a class="dropdown-item" href="<?php echo ROOT_URL; ?>przeprosiny">Przeprosiny</a>
          <a class="dropdown-item" href="<?php echo ROOT_URL; ?>rocznice">Rocznice</a>
          <a class="dropdown-item" href="<?php echo ROOT_URL; ?>podziekowanie">Podziękowanie</a>
          <a class="dropdown-item" href="<?php echo ROOT_URL; ?>imieninyurodziny">Imieniny i Urodziny</a>
          <a class="dropdown-item" href="<?php echo ROOT_URL; ?>dzienkobiet">Dzień Kobiet</a>
        </div>
      </li>
      <li class="nav-item active">
        <a class="nav-link"  href="<?php echo ROOT_URL; ?>kreator">Stwórz bukiet</a>
      </li>
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo ROOT_URL; ?>szybkie-zamowienie">Złóż zamówienie</a>
      </li>
       <li class="nav-item active">
        <a class="nav-link" href="<?php echo ROOT_URL; ?>galeria">Galeria</a>
      </li>
	
      </ul>
		</div>
	  
	 
		<div class="col-sm-5 offset-sm-1 text-right">
		<ul class="nav nav-tabs nav-flex">
		 <li class="nav-item active">
        <a class="nav-link" href="#">Koszyk <i class="fa fa-shopping-basket" aria-hidden="true"></i> </a>
      </li>
      
     
      <li class="nav-item active">
         <a class="nav-link" href="#" id="myAccount" data-toggle="modal" data-target="#myAccountModal">Moje konto <i class="fa fa-user-circle-o" aria-hidden="true"></i> </a>
      </li>
      
   <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="text" placeholder="Wpisz nazwę produktu">
      <button class="btn btn-default" type="submit">Szukaj </button>
    </form>
    
    
    </ul>
  </div> </div> </div>
</nav>
        
   <!-- <div class="container-fluid"> -->
   <?php  
   require ($view);    
    ?>

	<!--</div><!-- /.container -->
        
          
      <!--footer-->
      <footer class="container-fluid">
            <div class="row">
              
                  <div class="col-md-4 text-center">
                   <br><br><br><br>
                  	 <p class="bigger">Kontakt</p>
                        <ul class="list-unstyled">
                              <li>
                                    <i class="fa fa-envelope" aria-hidden="true"></i> laetitia@kwiaciarnia.pl</li>
                              <li>
                                    <i class="fa fa-phone" aria-hidden="true"></i> 549-461-461</li>
                              <li>
                                    <i class="fa fa-location-arrow" aria-hidden="true"></i> Bydgoszcz ul. Kwiatowa 14</li>
                        </ul>
                  </div>
                     <div class="col-md-4 text-center logo">
                        <div><img src="<?php echo ROOT_PATH; ?>assets/img/logolwobg.png" height="200px" id="logo"></div>
                        <!-- <div class="l2">Kwiaciarnia</div> -->
                        <p>Kwiaciarnię Laetitia cechuje jakość produktów. Dba o własnych dostawców. </p>
                        
					 
                  </div>
                
                  <div class="col-md-4 text-center">
                       <br><br><br>
                        <p class="p-0 m-0 bigger">Polub nas na:</p>
                        <div class="sm">
                              <img src="<?php echo ROOT_PATH; ?>assets/img/sm (1).png" width="40px" alt="">
                        </div>
                        <div class="sm">
                              <img src="<?php echo ROOT_PATH; ?>assets/img/sm (2).png" width="40px" alt="">
                        </div>
                        <div class="sm">
                              <img src="<?php echo ROOT_PATH; ?>assets/img/sm (3).png" width="40px" alt="">
                        </div>
                        <br><br>
                        <p class="m-0 smaller">Chcesz otrzymywać newsletter?</p>
                        <form action="javascript:void(0)">
                              <input type="e-mail" placeholder="Wpisz e-mail">
                              <br>
                              <input type="submit" value="SUBSKRYBUJ" id="sub">
                        </form>
                  </div>
            </div>
            <hr>
            <div class="row" id="down-foot">
                  
                  <div class="col-sm-12 text-center">
                        <i>Copyright &copy; 2018
                              <br> Kwiaciarnia Laetitia</i>
                  </div>
                 
            </div>
      </footer>



     <!-- MODAL BOX MY ACCOUNT -->
      <div id="myAccountModal" class="modal fade" role="dialog">
            <div class="modal-dialog">
                  <div class="modal-content">
                        <div class="modal-body" id="modal-body-myAccount">
                              <div id="modal-wrapper">
                                    <div class="row mt-2 p-2">
                                          <div class="col-sm-12 text-center" style="font-family: 'Clicker Script', cursive; font-size: 36px; color:floralwhite;">Logowanie</div>
                                    </div>
                                    <form action="#">
                                          <div class="row">
                                                <div class="col-sm-12 text-center">
                                                      <i class="fa fa-user" aria-hidden="true"></i>
                                                      <input type="text" id="login-user" placeholder="Nazwa użytkownika" name="user-login">
                                                </div>
                                          </div>
                                          <div class="row mt-1">
                                                <div class="col-sm-12 text-center mt-1">
                                                      <i class="fa fa-unlock-alt" aria-hidden="true"></i>
                                                      <input type="password" id="login-pass" placeholder="Hasło" name="pass-user">
                                                </div>
                                          </div>
                                          <div class="row">
                                                <div class="col-sm-12 mt-1 text-center">
                                                      <label class="switch">
                                                            <input type="checkbox" id="rem-me">
                                                            <span class="slider round"></span>
                                                            Zapamiętaj mnie
                                                            <span style="margin-left:5px;">|</span>
                                                      </label>
                                                      <a href="#">
                                                            <span style="margin-left:5px">Nie pamiętasz hasła?</span>
                                                      </a>
                                                </div>
                                          </div>
                                          <div class="row">
                                                <div class="col-sm-12 text-center">
                                                      <button id="log-in" name="log-in-me">
                                                            <div id="hovDot"></div>
                                                            <i id="rArrow" class="fa fa-arrow-right" aria-hidden="true"></i>
                                                      </button>
                                                </div>
                                          </div>

                                    </form>
                                    <h4>LUB</h4>
                                    <div class="row text-center">
                                          <p class="text-center log-with">Zaloguj się za pomocą:</p>
                                    </div>
                                    <div class="row social-media">

                                          <div class="col-sm-4" id="tw">
                                                <div id="hovDotTw"></div>
                                                <i class="fa fa-twitter" aria-hidden="true"></i>
                                          </div>
                                          <div class="col-sm-4" id="fb">
                                                <div id="hovDotFb"></div>
                                                <i class="fa fa-facebook" aria-hidden="true"></i>
                                          </div>
                                          <div class="col-sm-4" id="gplus">
                                                <div id="hovDotGplus"></div>
                                                <i class="fa fa-google-plus" aria-hidden="true"></i>
                                          </div>
                                    </div>
                                    <hr style="background-color:floralwhite; margin-top:30px">
                                    <div class="row pt-2">
                                          <div class="col-sm-12 text-center">
                                                <div id="createAccount" class="hvr-icon-wobble-horizontal">Utwórz konto</div>
                                          </div>
                                    </div>
                              </div>
                              <!-- REGISTRATION REGISTRATION REGISTRATION REGISTRATION REGISTRATION REGISTRATION -->
                              <div id="registration-wrapper">
                                    <div class="row mt-2 p-2">
                                          <div class="col-sm-12 text-center" style="font-family: 'Clicker Script', cursive; font-size: 36px; color:floralwhite;">Rejestracja</div>
                                    </div>
                                    
                                    <form action="#" class="mt-1">
                                          <div class="row">
                                                <div class="col-md-12 text-center">
                                                      <i class="fa fa-user" aria-hidden="true"></i>
                                                      <input type="text" id="name" placeholder="Nazwa użytkownika" required>
                                                      <br>
                                                      <i class="fa fa-envelope-o" aria-hidden="true"></i>
                                                      <input type="email" id="regEmail" placeholder="E-mail" required>
                                                      <br>
                                                      <i class="fa fa-unlock-alt" aria-hidden="true"></i>
                                                      <input type="password" id="regPassword" placeholder="Hasło" required>
                                                      <input type="password" id="regRepassword" placeholder="Powtórz hasło" required>
                                                      <br>
                                                      <i class="fa fa-phone" aria-hidden="true"></i>
                                                      <input type="number" id="regTel" placeholder="Telefon" required>
                                                      <br>
                                                      <p class="m-0 p-0" style="font-size:14px;color:#b3b7cc">Rejestrując się, zgadzasz się na zasady
                                                            <u>regulaminu</u>
                                                      </p>
                                                      <button id="regSubmit">Zarejestruj się</button>
                                                </div>
                                          </div>
                                    </form>
                                    <hr class="mt-4">
                                    <div class="row text-center">
                                          <p class="text-center log-with">Masz już konto?
                                                <span id="backToLog">Zaloguj się</span>
                                          </p>
                                    </div>
                              </div>
                        </div>
                  </div>
            </div>
    




      <!-- JS -->
      <script type="text/javascript" src="<?php echo ROOT_PATH; ?>assets/js/jquery-2.0.2.js"></script>
      <script type="text/javascript" src="<?php echo ROOT_PATH; ?>assets/js/popper.min.js"></script>
      <script type="text/javascript" src="<?php echo ROOT_PATH; ?>assets/js/bootstrap.min.js"></script>
      <script type="text/javascript" src="<?php echo ROOT_PATH; ?>assets/js/ScrollMagic.min.js"> </script>
	  <script type="text/javascript" src="<?php echo ROOT_PATH; ?>assets/js/plugins/debug.addIndicators.min.js"></script>
	 
	  <script src="https://unpkg.com/scrollreveal/dist/scrollreveal.min.js"></script>
      
      <script src="<?php echo ROOT_PATH; ?>assets/js/kwiaciarnia.js"></script>
       <script src="<?php echo ROOT_PATH; ?>assets/js/jquery.twentytwenty.js"></script>
        <script src="<?php echo ROOT_PATH; ?>assets/js/jquery.event.move.js"></script>
        <script>
            /* moje funckje*/
            window.sr = ScrollReveal({ reset: false });
            sr.reveal('.foo',{duration: 4000});
      </script>
     

</body>

</html>