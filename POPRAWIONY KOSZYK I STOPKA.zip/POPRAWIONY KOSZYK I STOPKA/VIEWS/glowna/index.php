<div class="sticky"> <img src="<?php echo ROOT_PATH; ?>assets/img/daltonicon1.png" alt="daltonicon" title="Zmień kontrast" style="position: fixed;
	top: 13px;
	right: 0;
	width: 35px;
	z-index: 1;
	background: white;
	border: 1px solid black;"></div>

<div class="row">
	<div class="col-sm-12 p-0">
		<div class="slider">
			<div class="clouds">
				<div class="quotation">
					<p id="tutaj"></p> <br></div>
				<a href="#" class="btn btn-lg foo" role="button">Zobacz ofertę &rarr;</a>

			</div>
		</div>
	</div>
</div>



<section>

	<div class="row kreator foo m-5">

		<div class="col-md-6" id="rose">
			<img src="<?php echo ROOT_PATH; ?>assets/img/child-33314.svg" height="500px">

		</div>
		<div class="col-md-3">
			<hr>
			<h2>Jak zamówić?</h2>
			<hr>
			<div>
				<div>
					<h3><span class="fa-stack fa-1x">
  <i class="fa fa-circle-o fa-stack-2x"></i>
  <strong class="fa-stack-1x">1</strong>
</span></h3>
					<p><b>Przejdź do oferty naszej kwiaciarni.</b></p>
					<hr>
					<h3><span class="fa-stack fa-1x">
  <i class="fa fa-circle-o fa-stack-2x"></i>
  <strong class="fa-stack-1x">2</strong>
</span></h3>
					<p><b>Włóż do koszyka bukiety, które chcesz zamówić.</b></p>
					<hr>
					<h3><span class="fa-stack fa-1x">
  <i class="fa fa-circle-o fa-stack-2x"></i>
  <strong class="fa-stack-1x">3</strong>
</span></h3>
					<p><b>Wypełnij formularz i wyślij zamówienie, a nasi sprzedawcy się z Tobą skontaktują!</b></p>
				</div>
			</div>

		</div>
		<div class="col-md-3">
			<hr>
			<h2>Kreator</h2>
			<hr>
			<div><img src="<?php echo ROOT_PATH; ?>assets/img/bouquet.svg" height="100px" width="80px">
				<p class="h5"><b>Skomponuj swój własny bukiet!</b> </p>
				<p>Wypróbuj nasz internetowy kreator bukietów i pochwal się znajomym swoim dziełem! </p>
			</div> <br>
			<div><a href="#" class="btn">Przejdź do kreatora &rarr;</a></div>
		</div>
	</div>

</section>





<section>




	<div class="row foo">
		<div class="col-md-4 bloczek">
			<div class="block">
				<h1 class="floating"><span class="kolorek">M</span>OŻLIWOŚĆ <span class="kolorek">Z</span>MIANY <span class="kolorek">K</span>ONTRASTU</h1><span><img src="<?php echo ROOT_PATH; ?>assets/img/daltonicon1.png"></span></div>
			<p class="h6">Strona przystosowana dla osób z&nbspzaburzeniami percepcji barw.</p>
		</div>
		<div class="col-md-6 offset-sm-1 nod" id="donoda">
			<div class="box">
				<img src="<?php echo ROOT_PATH; ?>assets/img/tulipanyafter.png">
				<img src="<?php echo ROOT_PATH; ?>assets/img/tulipanybefore.png">
			</div>


		</div>
	</div>
</section>

<section>

	<div class="row foo">


		<div class="col-md-8">
			<div class="inspire">

				<h2><strong> Zobacz bukiety stworzone przez klientów!</strong> </h2>

				<p class="h6 text-muted"><br><br>Stwórz bukiet i udostępnij go na naszej stronie! <br><br><br> Podziel się swoimi pomysłami lub zainspiruj się dostępnymi szablonami! Lorem ipsum dolor sit amet enim. Etiam ullamcorper. Suspendisse a pellentesque dui, non felis. Maecenas malesuada elit lectus felis, malesuada ultricies. </p>
				<br><br>
				<a href="#" class="btn btn-lg" role="button">Przejdź do galerii &rarr;</a>

			</div>

		</div>
		<div class="col-md-4">
			<div class="inspiresec"></div>
		</div>
	</div>



</section>
</div>